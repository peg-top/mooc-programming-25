# Write your solution here
age = int(input("How old are you? "))
print(f'You are {"not " if age < 18 else ""}of age!')