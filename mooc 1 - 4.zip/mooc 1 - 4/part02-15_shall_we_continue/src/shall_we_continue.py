while True:
    print("hi")
    yes_or_no = input("Shall we continue? ").strip().lower()
    if yes_or_no == "no":
        break
print("okay then")