# Write your solution here
s = input("Please write in a string: ")

i = 1

while i <= len(s):
    print(s[:i])
    i += 1
