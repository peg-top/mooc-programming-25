# Write your solution here
number1 = int(input("Number 1: "))
number2 = int(input("Number 2: "))
print(f'The sum of the numbers: {number1 + number2}')
print(f'The product of the numbers: {number1 * number2}')