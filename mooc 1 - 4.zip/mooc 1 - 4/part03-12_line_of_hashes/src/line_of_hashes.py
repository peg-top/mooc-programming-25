# Write your solution here
width = int(input("Width: "))

print("#" * width)