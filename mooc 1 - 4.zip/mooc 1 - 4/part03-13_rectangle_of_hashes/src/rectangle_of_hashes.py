# Write your solution here

w = int(input("Widht: "))
h = int(input("Height: "))

# a = "#" * w + "\n"
print(("#" * w + "\n") * h)
