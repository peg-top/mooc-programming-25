# Write your solution here
num = float(input("Please type in a number: "))
print(f'Integer part: {int(num)}')
print(f'Decimal part: {num - int(num)}')