# Write your solution here
n1 = int(input("Number 1: "))
n2 = int(input("Number 2: "))
n3 = int(input("Number 3: "))
n4 = int(input("Number 4: "))
sum = n1+n2+n3+n4
print(f'The sum of the numbers is {sum} and the mean is {sum/4}')