# Write your solution here
n = int(input("Upper limit:" ))
i = 1

while i < n:
    print(i)
    i += 1
