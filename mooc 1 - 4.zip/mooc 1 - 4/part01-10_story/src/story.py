# Write your solution here
name = input("Please type in a name: ")
year = input("Please type in a year: ")
print(f'{name} is a valiant knight, born in the year {year}. One morning {name} woke up to an awful racket: a dragon was approaching the village. Only {name} could save the village\'s residents.')