# Write your solution here
first_name = input("Given name: ")
second_name = input("Family name: ")
street_address = input("Street address: ")
city_postal_code = input("City and postal code: ")
print(first_name + " " + second_name)
print(street_address)
print(city_postal_code)