# Write your solution here
str = input("Please type in a word: ")

str_len = len(str)

if str_len > 1:
    print(f'There are {str_len} in the word {str}')
print("Thank you!")